#include <iostream>
using namespace std;

int main() {
    cout << "Mobile charge purchased successfully!" << endl;
    return 0;
}
