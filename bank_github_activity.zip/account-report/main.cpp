#include <iostream>
using namespace std;

int main() {
    cout << "Account report generated successfully!" << endl;
    return 0;
}
