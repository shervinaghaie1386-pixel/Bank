# Banking System - University Activity

A minimal Git/GitHub branching activity demonstrating three banking services.

## Branches
- `money-transfer`: Money transfer operation
- `buy-charge`: Mobile charge purchase operation
- `account-report`: Account report operation

Each service branch contains a `main.cpp` file with a simple success message.
